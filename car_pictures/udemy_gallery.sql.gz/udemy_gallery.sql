-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2019 m. Kov 12 d. 11:25
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `udemy_gallery`
--

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `comments`
--

INSERT INTO `comments` (`id`, `photo_id`, `author`, `body`, `date_created`, `date_updated`) VALUES
(1, 5, 'Tadas', 'because im batman', '2019-03-06 10:58:28', '0000-00-00 00:00:00'),
(2, 5, 'Erika', 'kas batmans?', '2019-03-06 11:08:23', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `photos`
--

CREATE TABLE `photos` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `caption` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alternate_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `photos`
--

INSERT INTO `photos` (`id`, `title`, `caption`, `description`, `filename`, `alternate_text`, `type`, `size`) VALUES
(5, 'Batman', 'Because I\'m Batman', '<ul><li>I am vengeance, I am night, I am batman<strong> asdasdasdd &nbsp;asd</strong></li></ul>', 'icons8_Batman.ico', 'Batman', 'image/x-icon', 5430),
(7, 'titulas', 'Erikos nuotrauka', '<p>hlkhnlk</p>', 'erika.png', 'Erika', 'image/png', 602193),
(23, 'Balsis', 'AS', '<figure class=\"table\"><table><tbody><tr><td>SAD<strong>ASD</strong></td></tr><tr><td>&nbsp;</td></tr></tbody></table></figure>', 'IMG-6166ad1cd3734b645626aa80e6adbc5e-V.jpg', 'ASD', 'image/jpeg', 4103049),
(25, 'sadas', '', '', 'images-14.jpg', '', 'image/jpeg', 21992),
(26, 'sada', '', '', 'image_3.jpg', '', 'image/jpeg', 59467),
(29, 'titulas', '', '', 'images-24 copy.jpg', '', 'image/jpeg', 29850),
(30, '', '', '', 'images-6 copy.jpg', '', 'image/jpeg', 21886),
(31, '', '', '', 'images-6.jpg', '', 'image/jpeg', 21886),
(32, '', '', '', 'images-7 copy.jpg', '', 'image/jpeg', 24140),
(33, '', '', '', 'images-5 copy.jpg', '', 'image/jpeg', 33192),
(34, '', '', '', 'images-5.jpg', '', 'image/jpeg', 33192),
(35, '', '', '', 'images-36 copy.jpg', '', 'image/jpeg', 21672),
(36, '', '', '', 'images-35.jpg', '', 'image/jpeg', 23672),
(37, '', '', '', 'images-36.jpg', '', 'image/jpeg', 21672),
(38, '', '', '', 'images-37 copy.jpg', '', 'image/jpeg', 20381),
(39, '', '', '', 'images-37.jpg', '', 'image/jpeg', 20381),
(40, '', '', '', 'images-38 copy.jpg', '', 'image/jpeg', 21857),
(41, '', '', '', 'images-38.jpg', '', 'image/jpeg', 21857),
(42, '', '', '', 'images-39 copy.jpg', '', 'image/jpeg', 24969),
(43, '', '', '', 'images-39.jpg', '', 'image/jpeg', 24969),
(44, '', '', '', 'images-40 copy.jpg', '', 'image/jpeg', 24385),
(45, '', '', '', 'images-40.jpg', '', 'image/jpeg', 24385),
(46, '', '', '', 'images-41 copy.jpg', '', 'image/jpeg', 16296),
(47, '', '', '', 'images-41.jpg', '', 'image/jpeg', 16296),
(48, '', '', '', 'images-42 copy.jpg', '', 'image/jpeg', 22401),
(49, '', '', '', 'images-42.jpg', '', 'image/jpeg', 22401),
(50, '', '', '', 'images-43 copy.jpg', '', 'image/jpeg', 27955),
(51, '', '', '', 'images-43.jpg', '', 'image/jpeg', 27955),
(52, '', '', '', 'images-44 copy.jpg', '', 'image/jpeg', 29486),
(53, '', '', '', 'images-44.jpg', '', 'image/jpeg', 29486),
(54, '', '', '', 'images-50 copy.jpg', '', 'image/jpeg', 21652),
(55, '', '', '', 'images-50.jpg', '', 'image/jpeg', 21652),
(56, '', '', '', '.DS_Store', '', 'application/octet-stream', 6148),
(57, '', '', '', '_large_image_1.jpg', '', 'image/jpeg', 479843),
(58, '', '', '', '_large_image_2.jpg', '', 'image/jpeg', 309568),
(59, '', '', '', '_large_image_3.jpg', '', 'image/jpeg', 165053),
(60, '', '', '', '_large_image_4.jpg', '', 'image/jpeg', 554659),
(61, '', '', '', 'image-1 copy.jpg', '', 'image/jpeg', 328747),
(62, '', '', '', 'image-1.jpg', '', 'image/jpeg', 328747),
(63, '', '', '', 'images_2.jpg', '', 'image/jpeg', 18578),
(64, '', '', '', 'images-1 copy.jpg', '', 'image/jpeg', 28947),
(65, '', '', '', 'images-1.jpg', '', 'image/jpeg', 28947),
(66, '', '', '', 'images-2 copy.jpg', '', 'image/jpeg', 18578),
(67, '', '', '', 'images-3 copy.jpg', '', 'image/jpeg', 18096),
(68, '', '', '', 'images-3.jpg', '', 'image/jpeg', 18096),
(69, '', '', '', 'images-4 copy.jpg', '', 'image/jpeg', 23270),
(70, '', '', '', 'images-4.jpg', '', 'image/jpeg', 23270),
(71, '', '', '', 'images-7.jpg', '', 'image/jpeg', 24140),
(72, '', '', '', 'images-8 copy.jpg', '', 'image/jpeg', 20810),
(73, '', '', '', 'images-9 copy.jpg', '', 'image/jpeg', 21108),
(74, '', '', '', 'images-8.jpg', '', 'image/jpeg', 20810),
(75, '', '', '', 'images-9.jpg', '', 'image/jpeg', 21108),
(76, '', '', '', 'images-10 copy.jpg', '', 'image/jpeg', 20401),
(77, '', '', '', 'images-10.jpg', '', 'image/jpeg', 20401),
(78, '', '', '', 'images-11 copy.jpg', '', 'image/jpeg', 27916),
(79, '', '', '', 'images-11.jpg', '', 'image/jpeg', 27916),
(80, '', '', '', 'images-12 copy.jpg', '', 'image/jpeg', 18540),
(81, '', '', '', 'images-12.jpg', '', 'image/jpeg', 18540),
(82, '', '', '', 'images-13 copy.jpg', '', 'image/jpeg', 22082),
(83, '', '', '', 'images-13.jpg', '', 'image/jpeg', 22082),
(84, '', '', '', 'images-14 copy.jpg', '', 'image/jpeg', 21992),
(85, '', '', '', 'images-15 copy.jpg', '', 'image/jpeg', 28466),
(86, '', '', '', 'images-15.jpg', '', 'image/jpeg', 28466),
(87, '', '', '', 'images-16 copy.jpg', '', 'image/jpeg', 21133),
(88, '', '', '', 'images-16.jpg', '', 'image/jpeg', 21133),
(89, '', '', '', 'images-17 copy.jpg', '', 'image/jpeg', 22792),
(90, '', '', '', 'images-17.jpg', '', 'image/jpeg', 22792),
(91, '', '', '', 'images-18 copy.jpg', '', 'image/jpeg', 27595),
(92, '', '', '', 'images-18.jpg', '', 'image/jpeg', 27595),
(93, '', '', '', 'images-19 copy.jpg', '', 'image/jpeg', 22792),
(94, '', '', '', 'images-19.jpg', '', 'image/jpeg', 22792),
(95, '', '', '', 'images-20 copy.jpg', '', 'image/jpeg', 22942),
(96, '', '', '', 'images-20.jpg', '', 'image/jpeg', 22942),
(97, '', '', '', 'images-21 copy.jpg', '', 'image/jpeg', 19957),
(98, '', '', '', 'images-21.jpg', '', 'image/jpeg', 19957),
(99, '', '', '', 'images-22 copy.jpg', '', 'image/jpeg', 21133),
(100, '', '', '', 'images-22.jpg', '', 'image/jpeg', 21133),
(101, '', '', '', 'images-23 copy.jpg', '', 'image/jpeg', 22792),
(102, '', '', '', 'images-23.jpg', '', 'image/jpeg', 22792),
(103, '', '', '', 'images-24.jpg', '', 'image/jpeg', 29850),
(104, '', '', '', 'images-25 copy.jpg', '', 'image/jpeg', 19363),
(105, '', '', '', 'images-25.jpg', '', 'image/jpeg', 19363),
(106, '', '', '', 'images-26 copy.jpg', '', 'image/jpeg', 21802),
(107, '', '', '', 'images-26.jpg', '', 'image/jpeg', 21802),
(108, '', '', '', 'images-27.jpg', '', 'image/jpeg', 17662),
(109, '', '', '', 'images-27 copy.jpg', '', 'image/jpeg', 17662),
(110, '', '', '', 'images-28 copy.jpg', '', 'image/jpeg', 17662),
(111, '', '', '', 'images-28.jpg', '', 'image/jpeg', 17662),
(112, '', '', '', 'images-29.jpg', '', 'image/jpeg', 25493),
(113, '', '', '', 'images-29 copy.jpg', '', 'image/jpeg', 25493),
(114, '', '', '', 'images-30 copy.jpg', '', 'image/jpeg', 20257),
(115, '', '', '', 'images-30.jpg', '', 'image/jpeg', 20257),
(116, '', '', '', 'images-31 copy.jpg', '', 'image/jpeg', 20928),
(117, '', '', '', 'images-31.jpg', '', 'image/jpeg', 20928),
(118, '', '', '', 'images-32 copy.jpg', '', 'image/jpeg', 22772),
(119, '', '', '', 'images-32.jpg', '', 'image/jpeg', 22772),
(120, '', '', '', 'images-33 copy.jpg', '', 'image/jpeg', 16855),
(121, '', '', '', 'images-33.jpg', '', 'image/jpeg', 16855),
(122, '', '', '', 'images-34 copy.jpg', '', 'image/jpeg', 23587);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `firstName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `firstName`, `lastName`, `user_image`) VALUES
(1, 'katusakai', 'asas', 'Tadas', 'Janca', 'tadas.png'),
(2, 'erikootee', 'erika', 'Erika', 'StraÅ¡inskaitÄ—', 'erika.png'),
(33, 'csharp', 'sharp', 'c', 'sharp', 'image_3.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `photo_id` (`photo_id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
